import React from 'react';
import Header from './Header';
import Post from './Post';
import Footer from './Footer';

function App() {
  return (
    <div className="App" style={{ padding: '30px', fontFamily: 'sans-serif' }}>
      <Header />
      <Post />
      <Footer />
    </div>
  );
}

export default App;
