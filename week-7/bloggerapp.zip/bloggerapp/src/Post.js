import React from 'react';

function Post() {
  const hasPosts = true;

  return (
    <div>
      <h3>Latest Post</h3>
      {hasPosts
        ? <p>React is fun! Let’s build amazing UIs.</p>
        : <p>No posts available.</p>
      }
    </div>
  );
}

export default Post;
