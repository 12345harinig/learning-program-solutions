import React from 'react';

function Footer() {
  const showCopyright = true;

  // Conditional rendering using && operator
  return (
    <div style={{ marginTop: '40px', fontSize: '0.9rem' }}>
      <p>Thanks for visiting our blog.</p>
      {showCopyright &&
        <p>© 2025 React Blogger. All rights reserved.</p>
      }
    </div>
  );
}

export default Footer;
