import React from 'react';

function Header() {
  const isMorning = true; // try changing to false

  // Conditional rendering using if
  if (!isMorning) {
    return <h2>Good Evening, Blogger!</h2>;
  }

  return <h2>Good Morning, Blogger!</h2>;
}

export default Header;
