import React from 'react';

class EventDemo extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      message: '',
      inputValue: ''
    };

    // Bind the method
    this.handleClick = this.handleClick.bind(this);
  }

  handleClick() {
    this.setState({ message: 'Button clicked!' });
  }

  handleChange = (e) => {
    this.setState({ inputValue: e.target.value });
  };

  render() {
    return (
      <div style={{ padding: '20px' }}>
        <h2>Event Handling Example</h2>

        <button onClick={this.handleClick}>Click Me</button>
        <p>{this.state.message}</p>

        <input
          type="text"
          placeholder="Type something..."
          onChange={this.handleChange}
          style={{ marginTop: '10px', padding: '5px' }}
        />
        <p>You typed: {this.state.inputValue}</p>
      </div>
    );
  }
}

export default EventDemo;
