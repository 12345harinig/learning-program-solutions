import React from 'react';
import EventDemo from './EventDemo';

function App() {
  return (
    <div className="App">
      <EventDemo />
    </div>
  );
}

export default App;
