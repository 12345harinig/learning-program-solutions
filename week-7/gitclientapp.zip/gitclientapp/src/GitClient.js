import axios from 'axios';

const GitClient = {
  getRepositories(username) {
    const url = `https://api.github.com/users/${username}/repos`;
    return axios.get(url).then(response => response.data);
  }
};

export default GitClient;
