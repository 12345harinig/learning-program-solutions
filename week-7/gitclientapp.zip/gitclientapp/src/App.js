import React from 'react';
import GitCommands from './components/GitCommands';

function App() {
  return (
    <div className="App">
      <h1>Git Client App</h1>
      <GitCommands />
    </div>
  );
}

export default App;
