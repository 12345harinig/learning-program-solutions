// src/components/GitCommands.js
import React from 'react';

const GitCommands = () => {
  return (
    <div style={{ padding: '20px' }}>
      <h2>Git Commands in React</h2>
      <ul>
        <li><code>git init</code> - Initialize a Git repo</li>
        <li><code>git add .</code> - Add all files</li>
        <li><code>git commit -m "message"</code> - Make a commit</li>
        <li><code>git push origin main</code> - Push to GitHub</li>
      </ul>
    </div>
  );
};

export default GitCommands;
