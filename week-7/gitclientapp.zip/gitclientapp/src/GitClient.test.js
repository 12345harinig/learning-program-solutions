import GitClient from './GitClient';
import axios from 'axios';

jest.mock('axios');

describe('GitClient', () => {
  it('fetches repositories for a user', async () => {
    const mockRepos = [{ id: 1, name: 'repo1' }, { id: 2, name: 'repo2' }];
    axios.get.mockResolvedValue({ data: mockRepos });

    const repos = await GitClient.getRepositories('testuser');
    expect(repos).toEqual(mockRepos);
  });
});
