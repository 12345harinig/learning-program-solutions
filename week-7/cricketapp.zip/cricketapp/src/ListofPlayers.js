import React from 'react';

const ListofPlayers = () => {
  const players = [
    { name: "Rohit Sharma", score: 95 },
    { name: "Virat Kohli", score: 88 },
    { name: "Shubman Gill", score: 45 },
    { name: "Hardik Pandya", score: 65 },
    { name: "Jasprit Bumrah", score: 30 },
    { name: "MS Dhoni", score: 98 },
    { name: "Ravindra Jadeja", score: 77 },
    { name: "Shreyas Iyer", score: 55 },
    { name: "Ishan Kishan", score: 49 },
    { name: "Mohammed Siraj", score: 28 },
    { name: "KL Rahul", score: 90 }
  ];

  const filtered = players.filter(p => p.score < 70);

  return (
    <div>
      <h2>All Players</h2>
      <ul>
        {players.map((p, i) => (
          <li key={i}>{p.name} - Score: {p.score}</li>
        ))}
      </ul>

      <h3>Players scored below 70</h3>
      <ul>
        {filtered.map((p, i) => (
          <li key={i}>{p.name} - {p.score}</li>
        ))}
      </ul>
    </div>
  );
};

export default ListofPlayers;
