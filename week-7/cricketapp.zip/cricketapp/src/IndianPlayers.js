import React from 'react';

const IndianPlayers = () => {
  const t20 = ["Rohit", "Virat", "Bumrah", "Gill", "Surya"];
  const ranji = ["Pujara", "Rahane", "Saha", "Yadav", "Jadeja"];

  // Destructuring
  const [oddTeam, evenTeam] = [t20.filter((_, i) => i % 2 === 0), t20.filter((_, i) => i % 2 !== 0)];

  // Merging arrays
  const merged = [...t20, ...ranji];

  return (
    <div>
      <h2>Indian Team Players</h2>
      <p><strong>Odd Team:</strong> {oddTeam.join(", ")}</p>
      <p><strong>Even Team:</strong> {evenTeam.join(", ")}</p>

      <h3>All Combined Players</h3>
      <p>{merged.join(", ")}</p>
    </div>
  );
};

export default IndianPlayers;
