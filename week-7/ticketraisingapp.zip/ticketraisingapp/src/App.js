import React from 'react';
import RaiseTicket from './RaiseTicket';

function App() {
  return (
    <div className="App">
      <RaiseTicket />
    </div>
  );
}

export default App;
