import React, { useState } from 'react';

const RaiseTicket = () => {
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    alert(`Ticket Raised by: ${name}\nDescription: ${description}`);
    // OR console.log({ name, description });
    setName('');
    setDescription('');
  };

  return (
    <div style={{ padding: '20px' }}>
      <h2>Raise a Ticket</h2>
      <form onSubmit={handleSubmit}>
        <div style={{ marginBottom: '10px' }}>
          <label>Your Name: </label><br />
          <input
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
            required
            style={{ width: '300px', padding: '5px' }}
          />
        </div>
        <div style={{ marginBottom: '10px' }}>
          <label>Description: </label><br />
          <textarea
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            required
            style={{ width: '300px', height: '100px', padding: '5px' }}
          />
        </div>
        <button type="submit">Submit Ticket</button>
      </form>
    </div>
  );
};

export default RaiseTicket;
