import React, { useState } from 'react';

const AddUserForm = () => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();

    const user = {
      name: name,
      email: email
    };

    fetch('https://jsonplaceholder.typicode.com/users', {
      method: 'POST',
      body: JSON.stringify(user),
      headers: {
        'Content-type': 'application/json; charset=UTF-8',
      }
    })
    .then((res) => res.json())
    .then((data) => {
      console.log('User added:', data);
      alert(`User added:\nName: ${data.name}\nEmail: ${data.email}`);
      setName('');
      setEmail('');
    })
    .catch((err) => console.error('Error:', err));
  };

  return (
    <div style={{ padding: '20px' }}>
      <h2>Add New User</h2>
      <form onSubmit={handleSubmit}>
        <div style={{ marginBottom: '10px' }}>
          <label>Name: </label><br />
          <input
            type="text"
            value={name}
            required
            onChange={(e) => setName(e.target.value)}
            style={{ width: '300px', padding: '5px' }}
          />
        </div>

        <div style={{ marginBottom: '10px' }}>
          <label>Email: </label><br />
          <input
            type="email"
            value={email}
            required
            onChange={(e) => setEmail(e.target.value)}
            style={{ width: '300px', padding: '5px' }}
          />
        </div>

        <button type="submit">Add User</button>
      </form>
    </div>
  );
};

export default AddUserForm;
