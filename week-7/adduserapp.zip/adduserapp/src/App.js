import React from 'react';
import AddUserForm from './AddUserForm';

function App() {
  return (
    <div className="App">
      <AddUserForm />
    </div>
  );
}

export default App;
