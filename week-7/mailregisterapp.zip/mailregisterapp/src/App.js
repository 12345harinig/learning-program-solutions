import React from 'react';
import RegisterForm from './RegisterForm';

function App() {
  return (
    <div className="App">
      <RegisterForm />
    </div>
  );
}

export default App;
