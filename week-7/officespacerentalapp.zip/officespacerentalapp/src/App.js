import React from 'react';
import OfficeSpace from './OfficeSpace';

function App() {
  return (
    <div className="App" style={{ padding: '20px' }}>
      <h1>🏢 Office Space Rental App</h1>
      <OfficeSpace />
    </div>
  );
}

export default App;
