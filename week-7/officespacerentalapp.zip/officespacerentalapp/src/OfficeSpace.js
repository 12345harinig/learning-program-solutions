import React from 'react';

const OfficeSpace = () => {
  const officeList = [
    {
      name: "GreenTech Towers",
      rent: 45000,
      address: "Anna Nagar, Chennai",
      image: "https://via.placeholder.com/300x150?text=GreenTech"
    },
    {
      name: "Skyline Spaces",
      rent: 75000,
      address: "T. Nagar, Chennai",
      image: "https://via.placeholder.com/300x150?text=Skyline"
    },
    {
      name: "UrbanHub Offices",
      rent: 62000,
      address: "Guindy, Chennai",
      image: "https://via.placeholder.com/300x150?text=UrbanHub"
    }
  ];

  return (
    <div>
      <h2>Office Space Listings</h2>
      {officeList.map((office, index) => (
        <div key={index} style={{
          border: '1px solid #ccc',
          padding: '15px',
          marginBottom: '20px',
          borderRadius: '8px',
          width: '320px'
        }}>
          <img src={office.image} alt={office.name} style={{ width: '100%' }} />
          <h3>{office.name}</h3>
          <p><strong>Address:</strong> {office.address}</p>
          <p style={{ color: office.rent < 60000 ? "red" : "green" }}>
            <strong>Rent:</strong> ₹{office.rent}
          </p>
        </div>
      ))}
    </div>
  );
};

export default OfficeSpace;
