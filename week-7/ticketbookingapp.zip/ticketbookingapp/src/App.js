import React from 'react';
import Booking from './Booking';

function App() {
  return (
    <div className="App">
      <Booking />
    </div>
  );
}

export default App;
