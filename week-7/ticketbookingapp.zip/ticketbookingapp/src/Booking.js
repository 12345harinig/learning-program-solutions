import React from 'react';

class Booking extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      isLoggedIn: false
    };
  }

  toggleLogin = () => {
    this.setState((prevState) => ({
      isLoggedIn: !prevState.isLoggedIn
    }));
  };

  render() {
    return (
      <div style={{ textAlign: 'center', marginTop: '40px' }}>
        <h2>Ticket Booking App</h2>
        <p>
          {this.state.isLoggedIn ? "Welcome User" : "Welcome Guest"}
        </p>
        <button onClick={this.toggleLogin}>
          {this.state.isLoggedIn ? "Logout" : "Login"}
        </button>
      </div>
    );
  }
}

export default Booking;
