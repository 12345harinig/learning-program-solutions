import React, { useState } from 'react';
import ThemeContext from './ThemeContext';
import ThemeToggle from './ThemeToggle';
import EmployeeList from './EmployeeList';

function App() {
  const [theme, setTheme] = useState('light');

  const toggleTheme = () =>
    setTheme(prev => (prev === 'light' ? 'dark' : 'light'));

  return (
    <ThemeContext.Provider value={{ theme, toggleTheme }}>
      <div style={{ padding: '30px', fontFamily: 'sans-serif' }}>
        <h2>Employee App using Context API</h2>
        <ThemeToggle />
        <EmployeeList />
      </div>
    </ThemeContext.Provider>
  );
}

export default App;
