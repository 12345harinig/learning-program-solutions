import React, { useContext } from 'react';
import ThemeContext from './ThemeContext';

const EmployeeList = () => {
  const { theme } = useContext(ThemeContext);

  const style = {
    background: theme === 'light' ? '#fff' : '#222',
    color: theme === 'light' ? '#000' : '#fff',
    padding: '10px',
    borderRadius: '5px'
  };

  return (
    <div style={style}>
      <h3>Employee List</h3>
      <ul>
        <li>Harini G</li>
        <li>Ammu </li>
        <li>Sharmila Mam</li>
      </ul>
    </div>
  );
};

export default EmployeeList;
