import React from 'react';
import styles from './CohortDetails.module.css';

function CohortDetails() {
  const cohorts = [
    { id: 1, name: "React Bootcamp", status: "ongoing" },
    { id: 2, name: "Java Fullstack", status: "completed" },
    { id: 3, name: "Cloud Foundation", status: "ongoing" },
    { id: 4, name: "DevOps with AWS", status: "completed" }
  ];

  return (
    <div>
      <h2>Cohort Dashboard</h2>
      {cohorts.map((cohort) => (
        <div key={cohort.id} className={styles.box}>
          <dt><strong>{cohort.name}</strong></dt>
          <p
            style={{
              color: cohort.status === "ongoing" ? "green" : "blue",
              fontWeight: "bold"
            }}
          >
            Status: {cohort.status}
          </p>
        </div>
      ))}
    </div>
  );
}

export default CohortDetails;
