import React from 'react';
import CohortDetails from './CohortDetails';

function App() {
  return (
    <div className="App">
      <CohortDetails />
    </div>
  );
}

export default App;
