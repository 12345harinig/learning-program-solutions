import React from 'react';
import Cart from './Cart';

class OnlineShopping extends React.Component {
  render() {
    const items = [
      { itemname: "Bluetooth Speaker", price: 1200 },
      { itemname: "Wired Headset", price: 650 },
      { itemname: "Wireless Mouse", price: 499 },
      { itemname: "Gaming Keyboard", price: 1300 },
      { itemname: "LED Monitor", price: 5000 }
    ];

    return (
      <div>
        <h2>Online Shopping Cart</h2>
        <div style={{ display: 'flex', flexWrap: 'wrap' }}>
          {items.map((item, index) => (
            <Cart key={index} itemname={item.itemname} price={item.price} />
          ))}
        </div>
      </div>
    );
  }
}

export default OnlineShopping;
