import React from 'react';

class Cart extends React.Component {
  render() {
    return (
      <div style={{
        border: '1px solid #aaa',
        padding: '10px',
        margin: '10px',
        borderRadius: '8px',
        width: '250px'
      }}>
        <h3>{this.props.itemname}</h3>
        <p>Price: ₹{this.props.price}</p>
      </div>
    );
  }
}

export default Cart;
