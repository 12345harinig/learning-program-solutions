const trainers = [
  {
    id: 1,
    name: "Harini G.",
    email: "harini@example.com",
    phone: "9876543210",
    technology: "React",
    skills: ["JS", "React", "Hooks"]
  },
  {
    id: 2,
    name: "Abinaya S.",
    email: "abinaya@example.com",
    phone: "9123456780",
    technology: "Java",
    skills: ["Java", "Spring", "Hibernate"]
  },
  {
    id: 3,
    name: "Sharmila M.",
    email: "sharmila@example.com",
    phone: "9988776655",
    technology: "Cloud",
    skills: ["AWS", "Docker", "K8s"]
  }
];

export default trainers;
