import React from 'react';

class CountPeople extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      entryCount: 0,
      exitCount: 0
    };
  }

  updateEntry = () => {
    this.setState(prevState => ({
      entryCount: prevState.entryCount + 1
    }));
  };

  updateExit = () => {
    this.setState(prevState => ({
      exitCount: prevState.exitCount + 1
    }));
  };

  render() {
    return (
      <div style={{
        border: '2px solid gray',
        width: '300px',
        margin: '40px auto',
        padding: '20px',
        borderRadius: '10px',
        textAlign: 'center'
      }}>
        <h2>Mall Entry Counter</h2>
        <p><strong>Number of people entered:</strong> {this.state.entryCount}</p>
        <p><strong>Number of people exited:</strong> {this.state.exitCount}</p>
        <button onClick={this.updateEntry} style={{ margin: '10px' }}>Login</button>
        <button onClick={this.updateExit} style={{ margin: '10px' }}>Exit</button>
      </div>
    );
  }
}

export default CountPeople;
